<?php
// File: local_teacherinfo/lang/en/local_teacherinfo.php

$string['pluginname'] = 'Teacher Info';
$string['teacherinfo'] = 'Teacher Info Service';
$string['teacherinfo_desc'] = 'Provides detailed information about teachers and their courses.';
